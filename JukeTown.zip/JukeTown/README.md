# JukeTown

A premium offline music player, organiser and tag editor for Android.
Kotlin + Jetpack Compose + Media3.

## Features

**Playback**
- Media3 / ExoPlayer engine with a background media session, lock-screen and notification controls
- Queue with play-next, add-to-queue and reordering
- Shuffle, repeat-one / repeat-all, playback speed, sleep timer
- System equaliser: presets, per-band control, bass boost

**Library**
- Home, Songs, Albums, Artists, Search and Library tabs
- Sort by title, artist, album, recently added or duration
- Folder browsing, playlists, favourites
- Instant search across songs, albums and artists

**Editing**
- Full tag editor: title, artist, album artist, album, genre, year, track, disc, composer, comment, lyrics
- Album art replacement — pick any image and embed it into the file
- Batch tag writing helper (`Tagging.batchSet`)

**Lyrics**
- Reads sidecar `.lrc` files and embedded lyric tags
- Synced, auto-scrolling display when timestamps are present

**Adding music**
- Import from a direct audio URL or a podcast RSS feed
- Files land in `Music/JukeTown` and appear in the library after a rescan

## Scope note

JukeTown plays and organises audio you already have, and imports audio you have the
rights to — your own recordings, Creative Commons and public-domain archives, podcast
feeds, and direct links. It does not integrate with DRM-protected streaming catalogues.

## Building

Push this repo to GitHub. The included workflow (`.github/workflows/build.yml`)
builds a debug APK on every push and attaches it to a rolling `latest` release,
plus a downloadable artifact on the Actions run.

You can also upload the zip itself — the workflow detects a `.zip` at the repo root,
unpacks it and builds from there.

Local build:

```
gradle assembleDebug
```

Requires JDK 17 and the Android SDK (compileSdk 34, minSdk 26).
