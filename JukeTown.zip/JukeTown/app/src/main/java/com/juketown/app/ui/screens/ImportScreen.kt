package com.juketown.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.RssFeed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.juketown.app.util.FeedItem
import com.juketown.app.util.Importer
import com.juketown.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportScreen(onBack: () -> Unit, onImported: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var mode by remember { mutableStateOf(0) } // 0 direct link, 1 feed
    var url by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var feedUrl by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<FeedItem>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var status by remember { mutableStateOf<String?>(null) }

    fun grab(link: String, title: String) {
        busy = true; progress = 0f; status = null
        scope.launch {
            val r = Importer.download(context, link, title) { progress = it }
            busy = false
            status = r.fold({ "Added \"$it\" to your library" }, { "Failed: ${it.message}" })
            if (r.isSuccess) onImported()
        }
    }

    Scaffold(
        containerColor = Ink,
        topBar = {
            TopAppBar(
                title = { Text("Add music") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Ink, titleContentColor = TextHi, navigationIconContentColor = TextHi
                )
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 20.dp)) {

            TabRow(selectedTabIndex = mode, containerColor = Ink, contentColor = Mint) {
                Tab(mode == 0, onClick = { mode = 0 },
                    text = { Text("Direct link") },
                    icon = { Icon(Icons.Rounded.Download, null) })
                Tab(mode == 1, onClick = { mode = 1 },
                    text = { Text("Podcast feed") },
                    icon = { Icon(Icons.Rounded.RssFeed, null) })
            }

            Spacer(Modifier.height(16.dp))

            val fieldColors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Mint, unfocusedBorderColor = InkCard,
                focusedTextColor = TextHi, unfocusedTextColor = TextHi,
                focusedLabelColor = Mint, unfocusedLabelColor = TextLo
            )

            if (mode == 0) {
                OutlinedTextField(url, { url = it }, label = { Text("Audio file URL") },
                    singleLine = true, shape = RoundedCornerShape(14.dp), colors = fieldColors,
                    modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(name, { name = it }, label = { Text("Save as") },
                    singleLine = true, shape = RoundedCornerShape(14.dp), colors = fieldColors,
                    modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { grab(url.trim(), name.ifBlank { url.substringAfterLast('/') }) },
                    enabled = !busy && url.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink),
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (busy) "Downloading…" else "Download") }
            } else {
                OutlinedTextField(feedUrl, { feedUrl = it }, label = { Text("RSS feed URL") },
                    singleLine = true, shape = RoundedCornerShape(14.dp), colors = fieldColors,
                    modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        busy = true
                        scope.launch {
                            val r = Importer.parseFeed(feedUrl.trim())
                            busy = false
                            r.onSuccess { items = it; status = "${it.size} episodes found" }
                                .onFailure { status = "Could not read feed: ${it.message}" }
                        }
                    },
                    enabled = !busy && feedUrl.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Load feed") }

                Spacer(Modifier.height(12.dp))
                LazyColumn(Modifier.weight(1f)) {
                    items(items) { item ->
                        ListItem(
                            headlineContent = { Text(item.title, color = TextHi, maxLines = 2,
                                overflow = TextOverflow.Ellipsis) },
                            supportingContent = { Text(item.author, color = TextLo) },
                            trailingContent = {
                                IconButton(onClick = { grab(item.audioUrl, item.title) }) {
                                    Icon(Icons.Rounded.Download, null, tint = Mint)
                                }
                            },
                            colors = ListItemDefaults.colors(containerColor = Ink)
                        )
                    }
                }
            }

            if (busy && progress > 0f) {
                Spacer(Modifier.height(14.dp))
                LinearProgressIndicator(progress = { progress }, color = Mint,
                    trackColor = InkCard, modifier = Modifier.fillMaxWidth())
            }
            status?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = if (it.startsWith("Failed") || it.startsWith("Could")) Coral else Mint)
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "For audio you have the rights to — your own recordings, Creative Commons and " +
                    "public-domain archives, podcast feeds, and direct links you're allowed to use.",
                color = TextLo, style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
