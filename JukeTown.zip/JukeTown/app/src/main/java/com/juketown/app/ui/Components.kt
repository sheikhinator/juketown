package com.juketown.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.juketown.app.data.Song
import com.juketown.app.ui.theme.*

@Composable
fun Artwork(model: Any?, size: Dp, corner: Dp = 12.dp, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(InkCard, InkElevated))),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = model,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        if (model == null) Icon(Icons.Filled.MusicNote, null, tint = TextLo)
    }
}

@Composable
fun SectionHeader(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, color = TextHi)
        Spacer(Modifier.weight(1f))
        if (action != null) Text(
            action,
            style = MaterialTheme.typography.labelSmall,
            color = Mint,
            modifier = Modifier.clickable(onClick = onAction)
        )
    }
}

@Composable
fun SongRow(
    song: Song,
    playing: Boolean = false,
    favourite: Boolean = false,
    onClick: () -> Unit,
    onMenu: () -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(song.artUri, 50.dp, 10.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                style = MaterialTheme.typography.titleMedium,
                color = if (playing) Mint else TextHi,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                "${song.artist} · ${formatMs(song.durationMs)}",
                style = MaterialTheme.typography.bodyMedium,
                color = TextLo, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (favourite) Icon(Icons.Rounded.Favorite, null, tint = Coral, modifier = Modifier.size(16.dp))
        if (playing) PlayingBars()
        IconButton(onClick = onMenu) {
            Icon(Icons.Rounded.MoreVert, null, tint = TextLo)
        }
    }
}

@Composable
fun PlayingBars() {
    val t = rememberInfiniteTransition(label = "bars")
    Row(Modifier.padding(start = 8.dp), verticalAlignment = Alignment.Bottom) {
        repeat(3) { i ->
            val h by t.animateFloat(
                initialValue = 4f, targetValue = 16f,
                animationSpec = infiniteRepeatable(
                    tween(420 + i * 130, easing = FastOutSlowInEasing), RepeatMode.Reverse
                ), label = "bar$i"
            )
            Box(
                Modifier
                    .padding(horizontal = 1.5.dp)
                    .size(width = 3.dp, height = h.dp)
                    .clip(CircleShape)
                    .background(Mint)
            )
        }
    }
}

@Composable
fun TileCard(title: String, subtitle: String, art: Any?, onClick: () -> Unit) {
    Column(
        Modifier
            .width(156.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        Artwork(art, 140.dp, 16.dp)
        Spacer(Modifier.height(10.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = TextHi,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = TextLo,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun GlowPill(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Mint else InkCard, label = "pill")
    val fg by animateColorAsState(if (selected) Ink else TextLo, label = "pillText")
    Box(
        Modifier
            .clip(CircleShape)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(text, color = fg, fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.bodyMedium)
    }
}

fun formatMs(ms: Long): String {
    val total = ms / 1000
    val m = total / 60
    val s = total % 60
    return "%d:%02d".format(m, s)
}
