package com.juketown.app.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class LyricLine(val timeMs: Long, val text: String)

data class Lyrics(val lines: List<LyricLine>, val synced: Boolean) {
    fun indexAt(positionMs: Long): Int {
        if (!synced) return -1
        var i = lines.indexOfLast { it.timeMs <= positionMs }
        if (i < 0) i = 0
        return i
    }
    val plain: String get() = lines.joinToString("\n") { it.text }
    companion object { val EMPTY = Lyrics(emptyList(), false) }
}

object LyricsLoader {

    private val TIME = Regex("""\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?]""")

    /**
     * Resolution order:
     *  1. sidecar .lrc next to the audio file (synced)
     *  2. LYRICS tag embedded in the file (synced if it contains [mm:ss] stamps)
     */
    suspend fun load(audioPath: String): Lyrics = withContext(Dispatchers.IO) {
        val lrc = File(audioPath.substringBeforeLast('.') + ".lrc")
        if (lrc.exists()) return@withContext parse(lrc.readText())
        val embedded = Tagging.read(audioPath).lyrics
        if (embedded.isNotBlank()) parse(embedded) else Lyrics.EMPTY
    }

    fun parse(raw: String): Lyrics {
        val out = ArrayList<LyricLine>()
        var synced = false
        raw.lineSequence().forEach { line ->
            val stamps = TIME.findAll(line).toList()
            val text = line.replace(TIME, "").trim()
            if (stamps.isEmpty()) {
                if (text.isNotEmpty()) out.add(LyricLine(0L, text))
            } else {
                synced = true
                stamps.forEach { m ->
                    val min = m.groupValues[1].toLong()
                    val sec = m.groupValues[2].toLong()
                    val frac = m.groupValues[3]
                    val ms = when (frac.length) {
                        0 -> 0L
                        1 -> frac.toLong() * 100
                        2 -> frac.toLong() * 10
                        else -> frac.toLong()
                    }
                    out.add(LyricLine(min * 60_000 + sec * 1000 + ms, text))
                }
            }
        }
        return Lyrics(out.sortedBy { it.timeMs }, synced && out.isNotEmpty())
    }

    suspend fun saveSidecar(audioPath: String, content: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching { File(audioPath.substringBeforeLast('.') + ".lrc").writeText(content) }
        }
}
