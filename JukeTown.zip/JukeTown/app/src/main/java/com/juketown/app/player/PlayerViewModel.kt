package com.juketown.app.player

import android.app.Application
import android.content.ComponentName
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.juketown.app.data.MusicRepository
import com.juketown.app.data.PlaylistStore
import com.juketown.app.data.Song
import com.juketown.app.util.Lyrics
import com.juketown.app.util.LyricsLoader
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PlayerUi(
    val current: Song? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val queue: List<Song> = emptyList(),
    val lyrics: Lyrics = Lyrics.EMPTY
)

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    private var controller: MediaController? = null
    private var equalizer: Equalizer? = null
    private var booster: LoudnessEnhancer? = null

    val store = PlaylistStore(app)

    private val _library = MutableStateFlow<List<Song>>(emptyList())
    val library: StateFlow<List<Song>> = _library.asStateFlow()

    private val _ui = MutableStateFlow(PlayerUi())
    val ui: StateFlow<PlayerUi> = _ui.asStateFlow()

    private val _favourites = MutableStateFlow(store.favourites())
    val favourites: StateFlow<Set<Long>> = _favourites.asStateFlow()

    private var queueSongs: List<Song> = emptyList()

    fun connect() {
        if (controller != null) return
        val token = SessionToken(getApplication(), ComponentName(getApplication(), PlaybackService::class.java))
        val future = MediaController.Builder(getApplication<Application>(), token).buildAsync()
        future.addListener({
            controller = future.get().also { c ->
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = sync()
                })
                sync()
            }
        }, MoreExecutors.directExecutor())

        viewModelScope.launch {
            while (true) {
                controller?.let { c ->
                    if (c.isPlaying) _ui.value = _ui.value.copy(
                        positionMs = c.currentPosition,
                        durationMs = c.duration.coerceAtLeast(0)
                    )
                }
                delay(500)
            }
        }
    }

    fun refreshLibrary(force: Boolean = false) = viewModelScope.launch {
        _library.value = MusicRepository.load(getApplication(), force)
    }

    private fun sync() {
        val c = controller ?: return
        val idx = c.currentMediaItemIndex
        val song = queueSongs.getOrNull(idx)
        val prev = _ui.value.current
        _ui.value = _ui.value.copy(
            current = song,
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition,
            durationMs = c.duration.coerceAtLeast(0),
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            queue = queueSongs
        )
        if (song != null && song.id != prev?.id) {
            attachEffects()
            viewModelScope.launch {
                _ui.value = _ui.value.copy(lyrics = LyricsLoader.load(song.data))
            }
        }
    }

    fun play(songs: List<Song>, startIndex: Int) {
        val c = controller ?: return
        queueSongs = songs
        c.setMediaItems(songs.map { it.toMediaItem() }, startIndex, 0L)
        c.prepare()
        c.play()
    }

    fun playNext(song: Song) {
        val c = controller ?: return
        val at = (c.currentMediaItemIndex + 1).coerceAtMost(queueSongs.size)
        queueSongs = queueSongs.toMutableList().apply { add(at, song) }
        c.addMediaItem(at, song.toMediaItem())
        sync()
    }

    fun addToQueue(song: Song) {
        val c = controller ?: return
        queueSongs = queueSongs + song
        c.addMediaItem(song.toMediaItem())
        sync()
    }

    fun removeFromQueue(index: Int) {
        val c = controller ?: return
        if (index !in queueSongs.indices) return
        queueSongs = queueSongs.toMutableList().apply { removeAt(index) }
        c.removeMediaItem(index)
        sync()
    }

    fun moveInQueue(from: Int, to: Int) {
        val c = controller ?: return
        queueSongs = queueSongs.toMutableList().apply { add(to, removeAt(from)) }
        c.moveMediaItem(from, to)
        sync()
    }

    fun toggle() = controller?.let { if (it.isPlaying) it.pause() else it.play() }
    fun next() = controller?.seekToNextMediaItem()
    fun previous() = controller?.let {
        if (it.currentPosition > 4000) it.seekTo(0) else it.seekToPreviousMediaItem()
    }
    fun seekTo(ms: Long) { controller?.seekTo(ms); _ui.value = _ui.value.copy(positionMs = ms) }
    fun setSpeed(v: Float) = controller?.setPlaybackSpeed(v)

    fun toggleShuffle() = controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    fun cycleRepeat() = controller?.let {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun toggleFavourite(id: Long) {
        store.toggleFavourite(id)
        _favourites.value = store.favourites()
    }

    // ---- Equaliser ----
    /**
     * Attaches to the global output mix (session 0) because MediaController does not expose
     * the service's audio session id. Requires MODIFY_AUDIO_SETTINGS.
     */
    private fun attachEffects() {
        if (equalizer != null) return
        runCatching {
            equalizer = Equalizer(0, 0).apply { enabled = true }
            booster = LoudnessEnhancer(0)
        }
    }

    fun bandCount(): Int = equalizer?.numberOfBands?.toInt() ?: 0
    fun bandRange(): Pair<Short, Short> =
        equalizer?.bandLevelRange?.let { it[0] to it[1] } ?: ((-1500).toShort() to 1500.toShort())
    fun bandFrequencyHz(i: Int): Int = (equalizer?.getCenterFreq(i.toShort()) ?: 0) / 1000
    fun bandLevel(i: Int): Short = equalizer?.getBandLevel(i.toShort()) ?: 0
    fun setBandLevel(i: Int, level: Short) { runCatching { equalizer?.setBandLevel(i.toShort(), level) } }
    fun presets(): List<String> =
        equalizer?.let { eq -> (0 until eq.numberOfPresets).map { eq.getPresetName(it.toShort()) } } ?: emptyList()
    fun usePreset(i: Int) { runCatching { equalizer?.usePreset(i.toShort()) } }
    fun setBassBoost(mB: Int) { runCatching { booster?.setTargetGain(mB); booster?.enabled = mB > 0 } }

    // ---- Sleep timer ----
    private var sleepJob: kotlinx.coroutines.Job? = null
    private val _sleepMinutesLeft = MutableStateFlow(0)
    val sleepMinutesLeft: StateFlow<Int> = _sleepMinutesLeft.asStateFlow()

    fun setSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        if (minutes <= 0) { _sleepMinutesLeft.value = 0; return }
        _sleepMinutesLeft.value = minutes
        sleepJob = viewModelScope.launch {
            repeat(minutes) {
                delay(60_000)
                _sleepMinutesLeft.value = _sleepMinutesLeft.value - 1
            }
            controller?.pause()
        }
    }

    override fun onCleared() {
        equalizer?.release(); booster?.release()
        controller?.release()
        super.onCleared()
    }
}

fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
    .setUri(uri)
    .setMediaId(id.toString())
    .setMediaMetadata(
        MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(artUri)
            .build()
    )
    .build()
