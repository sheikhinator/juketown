package com.juketown.app.util

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.images.ArtworkFactory
import java.io.ByteArrayOutputStream
import java.io.File

data class TrackTags(
    val title: String = "",
    val artist: String = "",
    val albumArtist: String = "",
    val album: String = "",
    val genre: String = "",
    val year: String = "",
    val track: String = "",
    val disc: String = "",
    val composer: String = "",
    val comment: String = "",
    val lyrics: String = ""
)

object Tagging {

    suspend fun read(path: String): TrackTags = withContext(Dispatchers.IO) {
        runCatching {
            val tag = AudioFileIO.read(File(path)).tagOrCreateAndSetDefault
            fun g(k: FieldKey) = runCatching { tag.getFirst(k) ?: "" }.getOrDefault("")
            TrackTags(
                title = g(FieldKey.TITLE),
                artist = g(FieldKey.ARTIST),
                albumArtist = g(FieldKey.ALBUM_ARTIST),
                album = g(FieldKey.ALBUM),
                genre = g(FieldKey.GENRE),
                year = g(FieldKey.YEAR),
                track = g(FieldKey.TRACK),
                disc = g(FieldKey.DISC_NO),
                composer = g(FieldKey.COMPOSER),
                comment = g(FieldKey.COMMENT),
                lyrics = g(FieldKey.LYRICS)
            )
        }.getOrDefault(TrackTags())
    }

    suspend fun write(path: String, t: TrackTags): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val f = AudioFileIO.read(File(path))
            val tag = f.tagOrCreateAndSetDefault
            fun s(k: FieldKey, v: String) { if (v.isNotBlank()) tag.setField(k, v) }
            s(FieldKey.TITLE, t.title)
            s(FieldKey.ARTIST, t.artist)
            s(FieldKey.ALBUM_ARTIST, t.albumArtist)
            s(FieldKey.ALBUM, t.album)
            s(FieldKey.GENRE, t.genre)
            s(FieldKey.YEAR, t.year)
            s(FieldKey.TRACK, t.track)
            s(FieldKey.DISC_NO, t.disc)
            s(FieldKey.COMPOSER, t.composer)
            s(FieldKey.COMMENT, t.comment)
            s(FieldKey.LYRICS, t.lyrics)
            f.commit()
        }
    }

    /** Embed a new cover image, replacing any existing artwork. */
    suspend fun writeArtwork(context: Context, path: String, image: Uri): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val bytes = context.contentResolver.openInputStream(image)!!.use { it.readBytes() }
                val tmp = File(context.cacheDir, "cover_tmp.jpg").apply { writeBytes(bytes) }
                val f = AudioFileIO.read(File(path))
                val tag = f.tagOrCreateAndSetDefault
                tag.deleteArtworkField()
                tag.setField(ArtworkFactory.createArtworkFromFile(tmp))
                f.commit()
                tmp.delete()
                Unit
            }
        }

    suspend fun writeArtwork(path: String, bitmap: Bitmap, cacheDir: File): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val out = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                val tmp = File(cacheDir, "cover_tmp.jpg").apply { writeBytes(out.toByteArray()) }
                val f = AudioFileIO.read(File(path))
                val tag = f.tagOrCreateAndSetDefault
                tag.deleteArtworkField()
                tag.setField(ArtworkFactory.createArtworkFromFile(tmp))
                f.commit()
                tmp.delete()
                Unit
            }
        }

    /** Batch-apply a field across many files. */
    suspend fun batchSet(paths: List<String>, key: FieldKey, value: String): Int =
        withContext(Dispatchers.IO) {
            var n = 0
            paths.forEach { p ->
                runCatching {
                    val f = AudioFileIO.read(File(p))
                    f.tagOrCreateAndSetDefault.setField(key, value)
                    f.commit(); n++
                }
            }
            n
        }
}
