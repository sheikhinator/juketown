package com.juketown.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.juketown.app.player.PlayerViewModel
import com.juketown.app.ui.GlowPill
import com.juketown.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerScreen(vm: PlayerViewModel, onBack: () -> Unit) {
    val bands = vm.bandCount()
    val (min, max) = vm.bandRange()
    var version by remember { mutableStateOf(0) }
    var bass by remember { mutableStateOf(0f) }
    var speed by remember { mutableStateOf(1f) }
    val presets = remember(version) { vm.presets() }
    var selectedPreset by remember { mutableStateOf(-1) }

    Scaffold(
        containerColor = Ink,
        topBar = {
            TopAppBar(
                title = { Text("Sound") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Ink, titleContentColor = TextHi, navigationIconContentColor = TextHi
                )
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(20.dp)) {
            if (bands == 0) {
                Text(
                    "The equaliser attaches once playback starts. Play something, then come back.",
                    color = TextLo
                )
                return@Column
            }

            Text("Presets", style = MaterialTheme.typography.titleLarge, color = TextHi)
            Spacer(Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presets.indices.toList()) { i ->
                    GlowPill(presets[i], selectedPreset == i) {
                        selectedPreset = i; vm.usePreset(i); version++
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            Text("Bands", style = MaterialTheme.typography.titleLarge, color = TextHi)
            repeat(bands) { i ->
                var level by remember(version, i) { mutableStateOf(vm.bandLevel(i).toFloat()) }
                Column(Modifier.padding(vertical = 6.dp)) {
                    Text(
                        "${vm.bandFrequencyHz(i)} Hz · ${(level / 100).toInt()} dB",
                        color = TextLo, style = MaterialTheme.typography.labelSmall
                    )
                    Slider(
                        value = level,
                        onValueChange = { level = it; vm.setBandLevel(i, it.toInt().toShort()) },
                        valueRange = min.toFloat()..max.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = Mint, activeTrackColor = Violet, inactiveTrackColor = InkCard
                        )
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Bass boost", color = TextHi, style = MaterialTheme.typography.titleMedium)
            Slider(
                value = bass, onValueChange = { bass = it; vm.setBassBoost(it.toInt()) },
                valueRange = 0f..1500f,
                colors = SliderDefaults.colors(thumbColor = Coral, activeTrackColor = Coral,
                    inactiveTrackColor = InkCard)
            )

            Spacer(Modifier.height(16.dp))
            Text("Playback speed · ${"%.2f".format(speed)}x", color = TextHi,
                style = MaterialTheme.typography.titleMedium)
            Slider(
                value = speed, onValueChange = { speed = it; vm.setSpeed(it) },
                valueRange = 0.5f..2f,
                colors = SliderDefaults.colors(thumbColor = Mint, activeTrackColor = Mint,
                    inactiveTrackColor = InkCard)
            )
            Spacer(Modifier.height(40.dp))
        }
    }
}
