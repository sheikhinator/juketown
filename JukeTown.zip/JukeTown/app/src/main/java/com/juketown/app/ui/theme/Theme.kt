package com.juketown.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Ink = Color(0xFF05060A)
val InkElevated = Color(0xFF0C0F18)
val InkCard = Color(0xFF141824)
val Mint = Color(0xFF3DF0C4)
val Violet = Color(0xFF7C5CFF)
val Coral = Color(0xFFFF6B8B)
val TextHi = Color(0xFFF2F4FA)
val TextLo = Color(0xFF9AA2B8)

val AuroraBrush = Brush.linearGradient(listOf(Mint, Violet))
val NightBrush = Brush.verticalGradient(listOf(Color(0xFF141A2E), Ink))

private val Scheme = darkColorScheme(
    primary = Mint,
    onPrimary = Ink,
    secondary = Violet,
    tertiary = Coral,
    background = Ink,
    onBackground = TextHi,
    surface = InkElevated,
    onSurface = TextHi,
    surfaceVariant = InkCard,
    onSurfaceVariant = TextLo,
    outline = Color(0xFF2A3145)
)

private val JukeType = Typography(
    displaySmall = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp),
    headlineMedium = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyMedium = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Normal),
    labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.6.sp)
)

@Composable
fun JukeTownTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = JukeType, content = content)
}
