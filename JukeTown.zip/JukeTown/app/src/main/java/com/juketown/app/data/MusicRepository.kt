package com.juketown.app.data

import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object MusicRepository {

    @Volatile private var cache: List<Song> = emptyList()

    suspend fun load(context: Context, force: Boolean = false): List<Song> =
        withContext(Dispatchers.IO) {
            if (cache.isNotEmpty() && !force) return@withContext cache
            val out = ArrayList<Song>(512)
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.ALBUM_ID,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.TRACK,
                MediaStore.Audio.Media.YEAR,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DATE_ADDED
            )
            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 20000"
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            )?.use { c ->
                val idI = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val tI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val arI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val alI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val alIdI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val dI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val trI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                val yI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
                val pI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val daI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                while (c.moveToNext()) {
                    val path = c.getString(pI) ?: continue
                    out.add(
                        Song(
                            id = c.getLong(idI),
                            title = c.getString(tI) ?: File(path).nameWithoutExtension,
                            artist = c.getString(arI)?.takeIf { it != "<unknown>" } ?: "Unknown artist",
                            album = c.getString(alI) ?: "Unknown album",
                            albumId = c.getLong(alIdI),
                            durationMs = c.getLong(dI),
                            track = c.getInt(trI),
                            year = c.getInt(yI),
                            genre = "",
                            data = path,
                            folder = File(path).parent ?: "",
                            dateAdded = c.getLong(daI)
                        )
                    )
                }
            }
            cache = out
            out
        }

    fun cached(): List<Song> = cache

    fun albums(songs: List<Song>): List<Album> = songs
        .groupBy { it.albumId }
        .map { (id, list) ->
            val f = list.first()
            Album(id, f.album, f.artist, list.size, list.maxOf { it.year })
        }
        .sortedBy { it.title.lowercase() }

    fun artists(songs: List<Song>): List<Artist> = songs
        .groupBy { it.artist }
        .map { (name, list) ->
            Artist(name, list.size, list.map { it.albumId }.distinct().size, list.firstOrNull()?.artUri)
        }
        .sortedByDescending { it.songCount }

    fun folders(songs: List<Song>): List<FolderNode> = songs
        .groupBy { it.folder }
        .map { (path, list) -> FolderNode(path, path.substringAfterLast('/'), list.size) }
        .sortedByDescending { it.songCount }

    fun search(songs: List<Song>, q: String): List<Song> {
        if (q.isBlank()) return emptyList()
        val n = q.trim().lowercase()
        return songs.filter {
            it.title.lowercase().contains(n) ||
                it.artist.lowercase().contains(n) ||
                it.album.lowercase().contains(n)
        }.sortedBy { it.title.lowercase().indexOf(n).let { i -> if (i < 0) 99 else i } }
    }
}
