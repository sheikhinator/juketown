package com.juketown.app

import android.app.Application

class JukeTownApp : Application()
