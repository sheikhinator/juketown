package com.juketown.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class PlaylistStore(context: Context) {
    private val prefs = context.getSharedPreferences("juketown_playlists", Context.MODE_PRIVATE)

    fun all(): List<Playlist> {
        val raw = prefs.getString("data", "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val ids = o.getJSONArray("songs")
            Playlist(
                o.getString("id"),
                o.getString("name"),
                (0 until ids.length()).map { ids.getLong(it) }
            )
        }
    }

    private fun persist(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            val o = JSONObject()
            o.put("id", p.id); o.put("name", p.name)
            o.put("songs", JSONArray().apply { p.songIds.forEach { put(it) } })
            arr.put(o)
        }
        prefs.edit().putString("data", arr.toString()).apply()
    }

    fun create(name: String): Playlist {
        val p = Playlist(UUID.randomUUID().toString(), name, emptyList())
        persist(all() + p); return p
    }

    fun addTo(playlistId: String, songId: Long) {
        persist(all().map { if (it.id == playlistId && songId !in it.songIds) it.copy(songIds = it.songIds + songId) else it })
    }

    fun removeFrom(playlistId: String, songId: Long) {
        persist(all().map { if (it.id == playlistId) it.copy(songIds = it.songIds - songId) else it })
    }

    fun delete(playlistId: String) = persist(all().filterNot { it.id == playlistId })

    fun rename(playlistId: String, name: String) =
        persist(all().map { if (it.id == playlistId) it.copy(name = name) else it })

    // Favourites are a reserved playlist
    fun favourites(): Set<Long> = prefs.getStringSet("favs", emptySet())!!.map { it.toLong() }.toSet()

    fun toggleFavourite(id: Long) {
        val cur = favourites().toMutableSet()
        if (!cur.add(id)) cur.remove(id)
        prefs.edit().putStringSet("favs", cur.map { it.toString() }.toSet()).apply()
    }
}
