package com.juketown.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.juketown.app.data.Playlist
import com.juketown.app.data.Song
import com.juketown.app.player.PlayerViewModel
import com.juketown.app.ui.Artwork
import com.juketown.app.ui.theme.*
import com.juketown.app.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { JukeTownTheme { Root() } }
    }
}

private enum class Section(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Rounded.Home),
    SONGS("Songs", Icons.Rounded.MusicNote),
    ALBUMS("Albums", Icons.Rounded.Album),
    ARTISTS("Artists", Icons.Rounded.Person),
    SEARCH("Search", Icons.Rounded.Search),
    LIBRARY("Library", Icons.Rounded.LibraryMusic)
}

private sealed interface Route {
    data object Main : Route
    data class Detail(val title: String, val songs: List<Song>) : Route
    data class Tags(val song: Song) : Route
    data object Equalizer : Route
    data object Import : Route
}

@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun Root() {
    val vm: PlayerViewModel = viewModel()
    val context = LocalContext.current

    val perms = buildList {
        if (Build.VERSION.SDK_INT >= 33) {
            add(Manifest.permission.READ_MEDIA_AUDIO)
            add(Manifest.permission.POST_NOTIFICATIONS)
        } else add(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    val permState = rememberMultiplePermissionsState(perms)

    LaunchedEffect(Unit) { permState.launchMultiplePermissionRequest() }
    LaunchedEffect(permState.allPermissionsGranted) {
        if (permState.allPermissionsGranted) { vm.connect(); vm.refreshLibrary() }
    }

    val library by vm.library.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val favourites by vm.favourites.collectAsStateWithLifecycle()
    val sleepLeft by vm.sleepMinutesLeft.collectAsStateWithLifecycle()

    var tab by remember { mutableStateOf(Section.HOME) }
    var route by remember { mutableStateOf<Route>(Route.Main) }
    var expanded by remember { mutableStateOf(false) }
    var menuSong by remember { mutableStateOf<Song?>(null) }
    var playlists by remember { mutableStateOf(vm.store.all()) }

    val onPlay: (List<Song>, Int) -> Unit = { list, i -> vm.play(list, i) }

    if (!permState.allPermissionsGranted) {
        PermissionGate { permState.launchMultiplePermissionRequest() }
        return
    }

    Box(Modifier.fillMaxSize().background(Ink)) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = InkElevated, tonalElevation = 0.dp) {
                    Section.values().forEach { t ->
                        NavigationBarItem(
                            selected = tab == t && route is Route.Main,
                            onClick = { tab = t; route = Route.Main },
                            icon = { Icon(t.icon, null) },
                            label = { Text(t.label, style = MaterialTheme.typography.labelSmall) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Ink, selectedTextColor = Mint,
                                indicatorColor = Mint, unselectedIconColor = TextLo,
                                unselectedTextColor = TextLo
                            )
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad)) {
                AnimatedContent(
                    targetState = route to tab,
                    transitionSpec = {
                        (fadeIn(tween(220)) + slideInHorizontally { it / 14 })
                            .togetherWith(fadeOut(tween(150)))
                    },
                    label = "nav"
                ) { (r, t) ->
                    when (r) {
                        is Route.Main -> when (t) {
                            Section.HOME -> HomeScreen(library, ui.current?.id, favourites, onPlay) { menuSong = it }
                            Section.SONGS -> SongsScreen(library, ui.current?.id, favourites, onPlay) { menuSong = it }
                            Section.ALBUMS -> AlbumsScreen(library) { a ->
                                route = Route.Detail(a.title, library.filter { it.albumId == a.id }.sortedBy { it.track })
                            }
                            Section.ARTISTS -> ArtistsScreen(library) { a ->
                                route = Route.Detail(a.name, library.filter { it.artist == a.name })
                            }
                            Section.SEARCH -> SearchScreen(library, ui.current?.id, favourites, onPlay) { menuSong = it }
                            Section.LIBRARY -> LibraryHub(
                                playlists = playlists,
                                favouriteCount = favourites.size,
                                library = library,
                                onOpenPlaylist = { p ->
                                    route = Route.Detail(p.name, library.filter { it.id in p.songIds })
                                },
                                onOpenFavourites = {
                                    route = Route.Detail("Favourites", library.filter { it.id in favourites })
                                },
                                onOpenFolder = { f ->
                                    route = Route.Detail(f.name, library.filter { it.folder == f.path })
                                },
                                onCreate = { n -> vm.store.create(n); playlists = vm.store.all() },
                                onDelete = { p -> vm.store.delete(p.id); playlists = vm.store.all() },
                                onImport = { route = Route.Import },
                                onEqualizer = { route = Route.Equalizer },
                                onRescan = { vm.refreshLibrary(force = true) }
                            )
                        }
                        is Route.Detail -> DetailScreen(
                            title = r.title, songs = r.songs, currentId = ui.current?.id,
                            favourites = favourites, onBack = { route = Route.Main },
                            onPlay = onPlay, onMenu = { menuSong = it }
                        )
                        is Route.Tags -> TagEditorScreen(r.song, { route = Route.Main }) {
                            vm.refreshLibrary(force = true)
                        }
                        Route.Equalizer -> EqualizerScreen(vm) { route = Route.Main }
                        Route.Import -> ImportScreen({ route = Route.Main }) { vm.refreshLibrary(force = true) }
                    }
                }
            }
        }

        // Mini player docked above the nav bar
        AnimatedVisibility(
            visible = ui.current != null && !expanded,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 84.dp)
        ) {
            MiniPlayer(
                song = ui.current,
                isPlaying = ui.isPlaying,
                progress = if (ui.durationMs > 0) ui.positionMs.toFloat() / ui.durationMs else 0f,
                onExpand = { expanded = true },
                onToggle = vm::toggle,
                onNext = vm::next
            )
        }

        AnimatedVisibility(
            visible = expanded && ui.current != null,
            enter = slideInVertically { it } + fadeIn(tween(200)),
            exit = slideOutVertically { it } + fadeOut(tween(200))
        ) {
            NowPlayingScreen(
                ui = ui,
                isFavourite = ui.current?.let { it.id in favourites } == true,
                sleepMinutesLeft = sleepLeft,
                onCollapse = { expanded = false },
                onToggle = vm::toggle,
                onNext = vm::next,
                onPrevious = vm::previous,
                onSeek = vm::seekTo,
                onShuffle = vm::toggleShuffle,
                onRepeat = vm::cycleRepeat,
                onFavourite = { ui.current?.let { vm.toggleFavourite(it.id) } },
                onEditTags = {
                    ui.current?.let { expanded = false; route = Route.Tags(it) }
                },
                onEqualizer = { expanded = false; route = Route.Equalizer },
                onSleepTimer = vm::setSleepTimer,
                onQueueSelect = { i -> vm.play(ui.queue, i) }
            )
        }
    }

    menuSong?.let { s ->
        SongSheet(
            song = s,
            playlists = playlists,
            isFavourite = s.id in favourites,
            onDismiss = { menuSong = null },
            onPlayNext = { vm.playNext(s); menuSong = null },
            onQueue = { vm.addToQueue(s); menuSong = null },
            onFavourite = { vm.toggleFavourite(s.id); menuSong = null },
            onEdit = { route = Route.Tags(s); menuSong = null },
            onAddToPlaylist = { p -> vm.store.addTo(p.id, s.id); playlists = vm.store.all(); menuSong = null },
            onGoToAlbum = {
                route = Route.Detail(s.album, library.filter { it.albumId == s.albumId }.sortedBy { it.track })
                menuSong = null
            }
        )
    }
}

@Composable
private fun PermissionGate(onRequest: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Ink), contentAlignment = Alignment.Center) {
        Column(Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("JUKETOWN", style = MaterialTheme.typography.labelSmall, color = Mint)
            Spacer(Modifier.height(10.dp))
            Text("Let JukeTown read your music", color = TextHi,
                style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(10.dp))
            Text("Audio access is needed to build your library. Nothing leaves your phone.",
                color = TextLo, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onRequest,
                colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink)) {
                Text("Grant access")
            }
        }
    }
}

@Composable
private fun MiniPlayer(
    song: Song?, isPlaying: Boolean, progress: Float,
    onExpand: () -> Unit, onToggle: () -> Unit, onNext: () -> Unit
) {
    song ?: return
    Column(
        Modifier
            .padding(horizontal = 12.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(InkCard)
            .clickable(onClick = onExpand)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Artwork(song.artUri, 44.dp, 10.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = TextHi, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleMedium)
                Text(song.artist, color = TextLo, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = onToggle) {
                Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Mint)
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Rounded.SkipNext, null, tint = TextHi)
            }
        }
        LinearProgressIndicator(
            progress = { progress.coerceIn(0f, 1f) },
            color = Mint, trackColor = InkElevated,
            modifier = Modifier.fillMaxWidth().height(2.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SongSheet(
    song: Song,
    playlists: List<Playlist>,
    isFavourite: Boolean,
    onDismiss: () -> Unit,
    onPlayNext: () -> Unit,
    onQueue: () -> Unit,
    onFavourite: () -> Unit,
    onEdit: () -> Unit,
    onAddToPlaylist: (Playlist) -> Unit,
    onGoToAlbum: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = InkElevated) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Artwork(song.artUri, 56.dp, 12.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(song.title, color = TextHi, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleMedium)
                Text(song.artist, color = TextLo, style = MaterialTheme.typography.bodyMedium)
            }
        }
        HorizontalDivider(color = InkCard)
        SheetRow(Icons.Rounded.QueuePlayNext, "Play next", onPlayNext)
        SheetRow(Icons.Rounded.AddToQueue, "Add to queue", onQueue)
        SheetRow(
            if (isFavourite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
            if (isFavourite) "Remove from favourites" else "Add to favourites", onFavourite
        )
        SheetRow(Icons.Rounded.Edit, "Edit tags & artwork", onEdit)
        SheetRow(Icons.Rounded.Album, "Go to album", onGoToAlbum)
        if (playlists.isNotEmpty()) {
            HorizontalDivider(color = InkCard)
            Text("Add to playlist", color = TextLo,
                modifier = Modifier.padding(start = 20.dp, top = 12.dp, bottom = 4.dp),
                style = MaterialTheme.typography.labelSmall)
            playlists.forEach { p ->
                SheetRow(Icons.Rounded.QueueMusic, p.name) { onAddToPlaylist(p) }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SheetRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Mint)
        Spacer(Modifier.width(16.dp))
        Text(label, color = TextHi, style = MaterialTheme.typography.titleMedium)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DetailScreen(
    title: String, songs: List<Song>, currentId: Long?, favourites: Set<Long>,
    onBack: () -> Unit, onPlay: (List<Song>, Int) -> Unit, onMenu: (Song) -> Unit
) {
    Scaffold(
        containerColor = Ink,
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = { onPlay(songs.shuffled(), 0) }) {
                        Icon(Icons.Rounded.Shuffle, null, tint = Mint)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Ink, titleContentColor = TextHi, navigationIconContentColor = TextHi
                )
            )
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(bottom = 160.dp)) {
            itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
                com.juketown.app.ui.SongRow(
                    s, s.id == currentId, s.id in favourites,
                    onClick = { onPlay(songs, i) }, onMenu = { onMenu(s) }
                )
            }
        }
    }
}
