package com.juketown.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.juketown.app.data.*
import com.juketown.app.ui.*
import com.juketown.app.ui.theme.*

enum class SongSort(val label: String) {
    TITLE("Title"), ARTIST("Artist"), ALBUM("Album"), RECENT("Recently added"), LONGEST("Duration")
}

fun List<Song>.sortedBy(sort: SongSort): List<Song> = when (sort) {
    SongSort.TITLE -> sortedBy { it.title.lowercase() }
    SongSort.ARTIST -> sortedBy { it.artist.lowercase() }
    SongSort.ALBUM -> sortedWith(compareBy({ it.album.lowercase() }, { it.track }))
    SongSort.RECENT -> sortedByDescending { it.dateAdded }
    SongSort.LONGEST -> sortedByDescending { it.durationMs }
}

@Composable
fun SongsScreen(
    songs: List<Song>,
    currentId: Long?,
    favourites: Set<Long>,
    onPlay: (List<Song>, Int) -> Unit,
    onMenu: (Song) -> Unit
) {
    var sort by remember { mutableStateOf(SongSort.TITLE) }
    val sorted = remember(songs, sort) { songs.sortedBy(sort) }

    LazyColumn(contentPadding = PaddingValues(bottom = 160.dp)) {
        item {
            Column {
                SectionHeader("${songs.size} songs")
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(SongSort.values().toList()) { s ->
                        GlowPill(s.label, sort == s) { sort = s }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                    FilledTonalButton(onClick = { onPlay(sorted, 0) }) {
                        Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Play all")
                    }
                    Spacer(Modifier.width(10.dp))
                    OutlinedButton(onClick = { onPlay(sorted.shuffled(), 0) }) {
                        Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Shuffle")
                    }
                }
            }
        }
        itemsIndexed(sorted, key = { _, s -> s.id }) { i, song ->
            SongRow(
                song = song,
                playing = song.id == currentId,
                favourite = song.id in favourites,
                onClick = { onPlay(sorted, i) },
                onMenu = { onMenu(song) }
            )
        }
    }
}

@Composable
fun AlbumsScreen(songs: List<Song>, onOpen: (Album) -> Unit) {
    val albums = remember(songs) { MusicRepository.albums(songs) }
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 160.dp)
    ) {
        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
            SectionHeader("${albums.size} albums")
        }
        items(albums, key = { it.id }) { a ->
            TileCard(a.title, a.artist, a.artUri) { onOpen(a) }
        }
    }
}

@Composable
fun ArtistsScreen(songs: List<Song>, onOpen: (Artist) -> Unit) {
    val artists = remember(songs) { MusicRepository.artists(songs) }
    LazyColumn(contentPadding = PaddingValues(bottom = 160.dp)) {
        item { SectionHeader("${artists.size} artists") }
        items(artists, key = { it.name }) { a ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(a) }
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Artwork(a.artUri, 54.dp, 27.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.name, style = MaterialTheme.typography.titleMedium, color = TextHi,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${a.songCount} songs · ${a.albumCount} albums",
                        style = MaterialTheme.typography.bodyMedium, color = TextLo)
                }
                Icon(Icons.Rounded.ChevronRight, null, tint = TextLo)
            }
        }
    }
}

@Composable
fun FoldersScreen(songs: List<Song>, onOpen: (FolderNode) -> Unit) {
    val folders = remember(songs) { MusicRepository.folders(songs) }
    LazyColumn(contentPadding = PaddingValues(bottom = 160.dp)) {
        item { SectionHeader("${folders.size} folders") }
        items(folders, key = { it.path }) { f ->
            ListItem(
                headlineContent = { Text(f.name, color = TextHi) },
                supportingContent = { Text("${f.songCount} songs · ${f.path}", color = TextLo,
                    maxLines = 1, overflow = TextOverflow.Ellipsis) },
                leadingContent = { Icon(Icons.Rounded.Folder, null, tint = Violet) },
                colors = ListItemDefaults.colors(containerColor = Ink),
                modifier = Modifier.clickable { onOpen(f) }
            )
        }
    }
}

@Composable
fun PlaylistsScreen(
    playlists: List<Playlist>,
    favouriteCount: Int,
    onOpen: (Playlist) -> Unit,
    onOpenFavourites: () -> Unit,
    onCreate: (String) -> Unit,
    onDelete: (Playlist) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(bottom = 160.dp)) {
        item {
            SectionHeader("Your playlists", "New") { showDialog = true }
            ListItem(
                headlineContent = { Text("Favourites", color = TextHi) },
                supportingContent = { Text("$favouriteCount songs", color = TextLo) },
                leadingContent = { Icon(Icons.Rounded.Favorite, null, tint = Coral) },
                colors = ListItemDefaults.colors(containerColor = Ink),
                modifier = Modifier.clickable(onClick = onOpenFavourites)
            )
        }
        items(playlists, key = { it.id }) { p ->
            ListItem(
                headlineContent = { Text(p.name, color = TextHi) },
                supportingContent = { Text("${p.songIds.size} songs", color = TextLo) },
                leadingContent = { Icon(Icons.Rounded.QueueMusic, null, tint = Mint) },
                trailingContent = {
                    IconButton(onClick = { onDelete(p) }) {
                        Icon(Icons.Rounded.DeleteOutline, null, tint = TextLo)
                    }
                },
                colors = ListItemDefaults.colors(containerColor = Ink),
                modifier = Modifier.clickable { onOpen(p) }
            )
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("New playlist") },
            text = {
                OutlinedTextField(value = name, onValueChange = { name = it },
                    singleLine = true, label = { Text("Name") })
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) onCreate(name.trim())
                    name = ""; showDialog = false
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancel") } }
        )
    }
}
