package com.juketown.app.data

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val track: Int,
    val year: Int,
    val genre: String,
    val data: String,
    val folder: String,
    val dateAdded: Long
) {
    val uri: Uri get() = Uri.parse("content://media/external/audio/media/$id")
    val artUri: Uri get() = Uri.parse("content://media/external/audio/albumart/$albumId")
}

data class Album(
    val id: Long,
    val title: String,
    val artist: String,
    val songCount: Int,
    val year: Int
) {
    val artUri: Uri get() = Uri.parse("content://media/external/audio/albumart/$id")
}

data class Artist(val name: String, val songCount: Int, val albumCount: Int, val artUri: Uri?)

data class Playlist(val id: String, val name: String, val songIds: List<Long>)

data class FolderNode(val path: String, val name: String, val songCount: Int)
