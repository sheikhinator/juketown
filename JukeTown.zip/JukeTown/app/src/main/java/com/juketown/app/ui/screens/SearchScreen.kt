package com.juketown.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.juketown.app.data.MusicRepository
import com.juketown.app.data.Song
import com.juketown.app.ui.*
import com.juketown.app.ui.theme.*

@Composable
fun SearchScreen(
    songs: List<Song>,
    currentId: Long?,
    favourites: Set<Long>,
    onPlay: (List<Song>, Int) -> Unit,
    onMenu: (Song) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val results = remember(query, songs) { MusicRepository.search(songs, query) }
    val albums = remember(results) { MusicRepository.albums(results).take(10) }
    val artists = remember(results) { MusicRepository.artists(results).take(10) }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Songs, albums, artists", color = TextLo) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Mint) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                    Icon(Icons.Rounded.Close, null, tint = TextLo)
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = InkCard, unfocusedContainerColor = InkCard,
                focusedBorderColor = Mint, unfocusedBorderColor = InkCard,
                focusedTextColor = TextHi, unfocusedTextColor = TextHi
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)
        )

        if (query.isBlank()) {
            EmptySearch()
        } else if (results.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Nothing matched \"$query\"", color = TextLo)
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 160.dp)) {
                if (artists.isNotEmpty()) {
                    item { SectionHeader("Artists") }
                    item {
                        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                            items(artists, key = { it.name }) { a ->
                                TileCard(a.name, "${a.songCount} songs", a.artUri) {
                                    onPlay(songs.filter { it.artist == a.name }, 0)
                                }
                            }
                        }
                    }
                }
                if (albums.isNotEmpty()) {
                    item { SectionHeader("Albums") }
                    item {
                        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                            items(albums, key = { it.id }) { a ->
                                TileCard(a.title, a.artist, a.artUri) {
                                    onPlay(songs.filter { it.albumId == a.id }.sortedBy { it.track }, 0)
                                }
                            }
                        }
                    }
                }
                item { SectionHeader("Songs · ${results.size}") }
                itemsIndexed(results, key = { _, s -> s.id }) { i, s ->
                    SongRow(s, s.id == currentId, s.id in favourites,
                        onClick = { onPlay(results, i) }, onMenu = { onMenu(s) })
                }
            }
        }
    }
}

@Composable
private fun EmptySearch() {
    Column(Modifier.fillMaxWidth().padding(24.dp)) {
        Text("Browse", style = MaterialTheme.typography.titleLarge, color = TextHi)
        Spacer(Modifier.height(12.dp))
        Text(
            "Search across every track, album and artist in your library. " +
                "Results update as you type.",
            color = TextLo, style = MaterialTheme.typography.bodyMedium,
            overflow = TextOverflow.Ellipsis
        )
    }
}
