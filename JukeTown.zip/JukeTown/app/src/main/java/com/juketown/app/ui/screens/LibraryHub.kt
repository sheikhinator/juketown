package com.juketown.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.juketown.app.data.FolderNode
import com.juketown.app.data.MusicRepository
import com.juketown.app.data.Playlist
import com.juketown.app.data.Song
import com.juketown.app.ui.GlowPill
import com.juketown.app.ui.SectionHeader
import com.juketown.app.ui.theme.*

@Composable
fun LibraryHub(
    playlists: List<Playlist>,
    favouriteCount: Int,
    library: List<Song>,
    onOpenPlaylist: (Playlist) -> Unit,
    onOpenFavourites: () -> Unit,
    onOpenFolder: (FolderNode) -> Unit,
    onCreate: (String) -> Unit,
    onDelete: (Playlist) -> Unit,
    onImport: () -> Unit,
    onEqualizer: () -> Unit,
    onRescan: () -> Unit
) {
    var section by remember { mutableStateOf(0) }
    var showDialog by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    val folders = remember(library) { MusicRepository.folders(library) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlowPill("Playlists", section == 0) { section = 0 }
            GlowPill("Folders", section == 1) { section = 1 }
            GlowPill("Tools", section == 2) { section = 2 }
        }

        when (section) {
            0 -> LazyColumn(contentPadding = PaddingValues(bottom = 160.dp)) {
                item {
                    SectionHeader("Your playlists", "New") { showDialog = true }
                    ListItem(
                        headlineContent = { Text("Favourites", color = TextHi) },
                        supportingContent = { Text("$favouriteCount songs", color = TextLo) },
                        leadingContent = { Icon(Icons.Rounded.Favorite, null, tint = Coral) },
                        colors = ListItemDefaults.colors(containerColor = Ink),
                        modifier = Modifier.clickable(onClick = onOpenFavourites)
                    )
                }
                items(playlists, key = { it.id }) { p ->
                    ListItem(
                        headlineContent = { Text(p.name, color = TextHi) },
                        supportingContent = { Text("${p.songIds.size} songs", color = TextLo) },
                        leadingContent = { Icon(Icons.Rounded.QueueMusic, null, tint = Mint) },
                        trailingContent = {
                            IconButton(onClick = { onDelete(p) }) {
                                Icon(Icons.Rounded.DeleteOutline, null, tint = TextLo)
                            }
                        },
                        colors = ListItemDefaults.colors(containerColor = Ink),
                        modifier = Modifier.clickable { onOpenPlaylist(p) }
                    )
                }
            }

            1 -> LazyColumn(contentPadding = PaddingValues(bottom = 160.dp)) {
                item { SectionHeader("${folders.size} folders") }
                items(folders, key = { it.path }) { f ->
                    ListItem(
                        headlineContent = { Text(f.name, color = TextHi) },
                        supportingContent = {
                            Text("${f.songCount} songs · ${f.path}", color = TextLo,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        },
                        leadingContent = { Icon(Icons.Rounded.Folder, null, tint = Violet) },
                        colors = ListItemDefaults.colors(containerColor = Ink),
                        modifier = Modifier.clickable { onOpenFolder(f) }
                    )
                }
            }

            else -> Column {
                ListItem(
                    headlineContent = { Text("Add music", color = TextHi) },
                    supportingContent = { Text("Direct links and podcast feeds", color = TextLo) },
                    leadingContent = { Icon(Icons.Rounded.Download, null, tint = Mint) },
                    colors = ListItemDefaults.colors(containerColor = Ink),
                    modifier = Modifier.clickable(onClick = onImport)
                )
                ListItem(
                    headlineContent = { Text("Equaliser & sound", color = TextHi) },
                    supportingContent = { Text("Bands, bass boost, speed", color = TextLo) },
                    leadingContent = { Icon(Icons.Rounded.Tune, null, tint = Violet) },
                    colors = ListItemDefaults.colors(containerColor = Ink),
                    modifier = Modifier.clickable(onClick = onEqualizer)
                )
                ListItem(
                    headlineContent = { Text("Rescan library", color = TextHi) },
                    supportingContent = { Text("${library.size} tracks indexed", color = TextLo) },
                    leadingContent = { Icon(Icons.Rounded.Refresh, null, tint = Coral) },
                    colors = ListItemDefaults.colors(containerColor = Ink),
                    modifier = Modifier.clickable(onClick = onRescan)
                )
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("New playlist") },
            text = {
                OutlinedTextField(value = name, onValueChange = { name = it },
                    singleLine = true, label = { Text("Name") })
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) onCreate(name.trim())
                    name = ""; showDialog = false
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancel") } }
        )
    }
}
