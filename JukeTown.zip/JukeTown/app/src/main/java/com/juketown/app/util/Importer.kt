package com.juketown.app.util

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL

/**
 * Imports audio the user already has the right to: their own uploads, direct links,
 * Creative Commons / public-domain archives, and podcast feeds.
 *
 * This deliberately does not integrate with DRM-protected streaming catalogues.
 */
data class FeedItem(val title: String, val author: String, val audioUrl: String, val mime: String)

object Importer {

    private const val UA = "JukeTown/1.0"

    suspend fun parseFeed(feedUrl: String): Result<List<FeedItem>> = withContext(Dispatchers.IO) {
        runCatching {
            val conn = (URL(feedUrl).openConnection() as HttpURLConnection).apply {
                setRequestProperty("User-Agent", UA); connectTimeout = 15000; readTimeout = 20000
            }
            conn.inputStream.use { input ->
                val parser = XmlPullParserFactory.newInstance().apply { isNamespaceAware = true }.newPullParser()
                parser.setInput(input, null)
                val items = ArrayList<FeedItem>()
                var title = ""; var author = ""; var url = ""; var mime = ""
                var text = ""
                var event = parser.eventType
                while (event != XmlPullParser.END_DOCUMENT) {
                    when (event) {
                        XmlPullParser.START_TAG -> {
                            if (parser.name.equals("item", true)) { title = ""; author = ""; url = ""; mime = "" }
                            if (parser.name.equals("enclosure", true)) {
                                url = parser.getAttributeValue(null, "url") ?: ""
                                mime = parser.getAttributeValue(null, "type") ?: "audio/mpeg"
                            }
                        }
                        XmlPullParser.TEXT -> text = parser.text ?: ""
                        XmlPullParser.END_TAG -> when {
                            parser.name.equals("title", true) && title.isBlank() -> title = text.trim()
                            parser.name.equals("author", true) && author.isBlank() -> author = text.trim()
                            parser.name.equals("item", true) && url.isNotBlank() ->
                                items.add(FeedItem(title.ifBlank { "Untitled" }, author, url, mime))
                        }
                    }
                    event = parser.next()
                }
                items
            }
        }
    }

    /**
     * Streams a direct audio URL into the shared Music collection and returns its display name.
     * onProgress receives 0f..1f, or -1f when the server sends no content length.
     */
    suspend fun download(
        context: Context,
        url: String,
        fileName: String,
        onProgress: (Float) -> Unit = {}
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val safe = fileName.replace(Regex("""[\\/:*?"<>|]"""), "_").let {
                if (it.contains('.')) it else "$it.mp3"
            }
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, safe)
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
                put(MediaStore.Audio.Media.IS_MUSIC, 1)
                put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/JukeTown")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val item = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Could not create the file")

            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                setRequestProperty("User-Agent", UA)
                instanceFollowRedirects = true
                connectTimeout = 15000; readTimeout = 30000
            }
            if (conn.responseCode !in 200..299) error("Server returned ${conn.responseCode}")
            val total = conn.contentLengthLong

            resolver.openOutputStream(item)!!.use { out ->
                conn.inputStream.use { input ->
                    val buf = ByteArray(64 * 1024)
                    var read: Int
                    var done = 0L
                    while (input.read(buf).also { read = it } != -1) {
                        out.write(buf, 0, read)
                        done += read
                        onProgress(if (total > 0) done.toFloat() / total else -1f)
                    }
                }
            }
            values.clear(); values.put(MediaStore.Audio.Media.IS_PENDING, 0)
            resolver.update(item, values, null, null)
            safe
        }
    }
}
