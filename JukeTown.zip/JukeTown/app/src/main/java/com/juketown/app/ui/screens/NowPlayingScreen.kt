package com.juketown.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import com.juketown.app.player.PlayerUi
import com.juketown.app.ui.Artwork
import com.juketown.app.ui.formatMs
import com.juketown.app.ui.theme.*

@Composable
fun NowPlayingScreen(
    ui: PlayerUi,
    isFavourite: Boolean,
    sleepMinutesLeft: Int,
    onCollapse: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onFavourite: () -> Unit,
    onEditTags: () -> Unit,
    onEqualizer: () -> Unit,
    onSleepTimer: (Int) -> Unit,
    onQueueSelect: (Int) -> Unit
) {
    val song = ui.current ?: return
    var tab by remember { mutableStateOf(0) } // 0 art, 1 lyrics, 2 queue
    var sleepSheet by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Ink)) {

        // Blurred artwork backdrop
        AsyncImage(
            model = song.artUri, contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().blur(70.dp).alpha(0.45f)
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, Ink.copy(alpha = 0.85f), Ink))
            )
        )

        Column(Modifier.fillMaxSize().padding(horizontal = 22.dp)) {
            Spacer(Modifier.height(28.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onCollapse) {
                    Icon(Icons.Rounded.KeyboardArrowDown, null, tint = TextHi)
                }
                Spacer(Modifier.weight(1f))
                Text(song.album.uppercase(), style = MaterialTheme.typography.labelSmall,
                    color = TextLo, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onEditTags) {
                    Icon(Icons.Rounded.Edit, null, tint = TextHi)
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                listOf("Cover", "Lyrics", "Queue").forEachIndexed { i, label ->
                    Text(
                        label,
                        style = MaterialTheme.typography.titleMedium,
                        color = if (tab == i) Mint else TextLo,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { tab = i }
                            .padding(vertical = 4.dp)
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            Box(Modifier.weight(1f).fillMaxWidth()) {
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = {
                        (fadeIn(tween(260)) + slideInVertically { it / 12 })
                            .togetherWith(fadeOut(tween(180)))
                    },
                    label = "npTab"
                ) { t ->
                    when (t) {
                        0 -> CoverPane(song.artUri, ui.isPlaying)
                        1 -> LyricsPane(ui)
                        else -> QueuePane(ui, onQueueSelect)
                    }
                }
            }

            Text(song.title, style = MaterialTheme.typography.headlineMedium, color = TextHi,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(song.artist, style = MaterialTheme.typography.titleMedium, color = TextLo,
                maxLines = 1, overflow = TextOverflow.Ellipsis)

            Spacer(Modifier.height(12.dp))

            var scrubbing by remember { mutableStateOf(false) }
            var scrubValue by remember { mutableStateOf(0f) }
            val duration = ui.durationMs.coerceAtLeast(1L)
            val progress = if (scrubbing) scrubValue else ui.positionMs.toFloat() / duration

            Slider(
                value = progress.coerceIn(0f, 1f),
                onValueChange = { scrubbing = true; scrubValue = it },
                onValueChangeFinished = {
                    onSeek((scrubValue * duration).toLong()); scrubbing = false
                },
                colors = SliderDefaults.colors(
                    thumbColor = Mint, activeTrackColor = Mint,
                    inactiveTrackColor = InkCard
                )
            )
            Row(Modifier.fillMaxWidth()) {
                Text(formatMs((progress * duration).toLong()), color = TextLo,
                    style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.weight(1f))
                Text(formatMs(ui.durationMs), color = TextLo,
                    style = MaterialTheme.typography.labelSmall)
            }

            Spacer(Modifier.height(8.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onShuffle) {
                    Icon(Icons.Rounded.Shuffle, null, tint = if (ui.shuffle) Mint else TextLo)
                }
                IconButton(onClick = onPrevious) {
                    Icon(Icons.Rounded.SkipPrevious, null, tint = TextHi, modifier = Modifier.size(34.dp))
                }
                PlayButton(ui.isPlaying, onToggle)
                IconButton(onClick = onNext) {
                    Icon(Icons.Rounded.SkipNext, null, tint = TextHi, modifier = Modifier.size(34.dp))
                }
                IconButton(onClick = onRepeat) {
                    Icon(
                        if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne
                        else Icons.Rounded.Repeat,
                        null,
                        tint = if (ui.repeatMode == Player.REPEAT_MODE_OFF) TextLo else Mint
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onClick = onFavourite) {
                    Icon(
                        if (isFavourite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        null, tint = if (isFavourite) Coral else TextLo
                    )
                }
                IconButton(onClick = onEqualizer) {
                    Icon(Icons.Rounded.Tune, null, tint = TextLo)
                }
                IconButton(onClick = { sleepSheet = true }) {
                    Icon(Icons.Rounded.Bedtime, null,
                        tint = if (sleepMinutesLeft > 0) Mint else TextLo)
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }

    if (sleepSheet) {
        AlertDialog(
            onDismissRequest = { sleepSheet = false },
            title = { Text("Sleep timer") },
            text = {
                Column {
                    if (sleepMinutesLeft > 0)
                        Text("$sleepMinutesLeft min remaining", color = Mint)
                    Spacer(Modifier.height(8.dp))
                    listOf(15, 30, 45, 60, 90).forEach { m ->
                        TextButton(onClick = { onSleepTimer(m); sleepSheet = false }) {
                            Text("$m minutes")
                        }
                    }
                    TextButton(onClick = { onSleepTimer(0); sleepSheet = false }) { Text("Off") }
                }
            },
            confirmButton = {}
        )
    }
}

@Composable
private fun PlayButton(isPlaying: Boolean, onToggle: () -> Unit) {
    val scale by animateFloatAsState(if (isPlaying) 1f else 0.94f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "playScale")
    Box(
        Modifier
            .scale(scale)
            .size(74.dp)
            .clip(CircleShape)
            .background(AuroraBrush)
            .clickable(onClick = onToggle),
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(isPlaying, transitionSpec = {
            (scaleIn() + fadeIn()).togetherWith(scaleOut() + fadeOut())
        }, label = "playIcon") { p ->
            Icon(
                if (p) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                null, tint = Ink, modifier = Modifier.size(38.dp)
            )
        }
    }
}

@Composable
private fun CoverPane(art: Any?, isPlaying: Boolean) {
    val scale by animateFloatAsState(if (isPlaying) 1f else 0.9f, tween(500), label = "artScale")
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Artwork(art, 300.dp, 26.dp, Modifier.scale(scale))
    }
}

@Composable
private fun LyricsPane(ui: PlayerUi) {
    val lyrics = ui.lyrics
    if (lyrics.lines.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                "No lyrics found.\nDrop a matching .lrc file next to the track, or paste lyrics in the tag editor.",
                color = TextLo, textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium
            )
        }
        return
    }
    val active = lyrics.indexAt(ui.positionMs)
    val state = rememberLazyListState()
    LaunchedEffect(active) {
        if (active >= 0) state.animateScrollToItem(maxOf(0, active - 2))
    }
    LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
        itemsIndexed(lyrics.lines) { i, line ->
            val on = i == active
            Text(
                line.text,
                color = if (on) Mint else TextLo,
                fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            )
        }
    }
}

@Composable
private fun QueuePane(ui: PlayerUi, onSelect: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(ui.queue) { i, s ->
            Row(
                Modifier.fillMaxWidth().clickable { onSelect(i) }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Artwork(s.artUri, 42.dp, 8.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.title, color = if (s.id == ui.current?.id) Mint else TextHi,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleMedium)
                    Text(s.artist, color = TextLo, maxLines = 1,
                        style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
