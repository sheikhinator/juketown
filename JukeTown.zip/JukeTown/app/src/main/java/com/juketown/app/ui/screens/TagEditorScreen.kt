package com.juketown.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.juketown.app.data.Song
import com.juketown.app.ui.Artwork
import com.juketown.app.ui.theme.*
import com.juketown.app.util.Tagging
import com.juketown.app.util.TrackTags
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TagEditorScreen(song: Song, onBack: () -> Unit, onSaved: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tags by remember { mutableStateOf(TrackTags()) }
    var loading by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf<String?>(null) }
    var pickedArt by remember { mutableStateOf<Uri?>(null) }

    LaunchedEffect(song.id) {
        tags = Tagging.read(song.data)
        if (tags.title.isBlank()) tags = tags.copy(title = song.title, artist = song.artist, album = song.album)
        loading = false
    }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) pickedArt = uri }

    Scaffold(
        containerColor = Ink,
        topBar = {
            TopAppBar(
                title = { Text("Edit track") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null) }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Ink, titleContentColor = TextHi, navigationIconContentColor = TextHi
                )
            )
        }
    ) { pad ->
        if (loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Mint)
            }
            return@Scaffold
        }
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Artwork(pickedArt ?: song.artUri, 110.dp, 16.dp)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("Album art", color = TextHi, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = { picker.launch("image/*") }) {
                        Icon(Icons.Rounded.Image, null); Spacer(Modifier.width(6.dp)); Text("Replace")
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            @Composable
            fun field(label: String, value: String, onChange: (String) -> Unit, single: Boolean = true) {
                OutlinedTextField(
                    value = value, onValueChange = onChange,
                    label = { Text(label) }, singleLine = single,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Mint, unfocusedBorderColor = InkCard,
                        focusedTextColor = TextHi, unfocusedTextColor = TextHi,
                        focusedLabelColor = Mint, unfocusedLabelColor = TextLo
                    )
                )
            }

            field("Title", tags.title) { tags = tags.copy(title = it) }
            field("Artist", tags.artist) { tags = tags.copy(artist = it) }
            field("Album artist", tags.albumArtist) { tags = tags.copy(albumArtist = it) }
            field("Album", tags.album) { tags = tags.copy(album = it) }
            field("Genre", tags.genre) { tags = tags.copy(genre = it) }
            Row {
                Box(Modifier.weight(1f)) { field("Year", tags.year) { tags = tags.copy(year = it) } }
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) { field("Track #", tags.track) { tags = tags.copy(track = it) } }
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) { field("Disc", tags.disc) { tags = tags.copy(disc = it) } }
            }
            field("Composer", tags.composer) { tags = tags.copy(composer = it) }
            field("Comment", tags.comment) { tags = tags.copy(comment = it) }
            field("Lyrics", tags.lyrics, { tags = tags.copy(lyrics = it) }, single = false)

            status?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = if (it.startsWith("Saved")) Mint else Coral)
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    scope.launch {
                        val r = Tagging.write(song.data, tags)
                        val artResult = pickedArt?.let { Tagging.writeArtwork(context, song.data, it) }
                        status = when {
                            r.isFailure -> "Could not write tags: ${r.exceptionOrNull()?.message}"
                            artResult?.isFailure == true -> "Tags saved, artwork failed"
                            else -> "Saved"
                        }
                        if (r.isSuccess) onSaved()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save changes") }

            Spacer(Modifier.height(10.dp))
            Text(
                "Writes directly into the file's ID3/Vorbis tags. On Android 11+ you may be asked " +
                    "to confirm the edit.",
                color = TextLo, style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(40.dp))
        }
    }
}
