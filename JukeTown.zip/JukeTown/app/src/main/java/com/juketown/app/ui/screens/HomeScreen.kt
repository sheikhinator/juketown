package com.juketown.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.juketown.app.data.MusicRepository
import com.juketown.app.data.Song
import com.juketown.app.ui.SectionHeader
import com.juketown.app.ui.SongRow
import com.juketown.app.ui.TileCard
import com.juketown.app.ui.theme.*

@Composable
fun HomeScreen(
    songs: List<Song>,
    currentId: Long?,
    favourites: Set<Long>,
    onPlay: (List<Song>, Int) -> Unit,
    onMenu: (Song) -> Unit
) {
    val recent = remember(songs) { songs.sortedByDescending { it.dateAdded }.take(12) }
    val albums = remember(songs) { MusicRepository.albums(songs).take(12) }
    val artists = remember(songs) { MusicRepository.artists(songs).take(12) }
    val picks = remember(songs) { songs.shuffled().take(8) }

    LazyColumn(contentPadding = PaddingValues(bottom = 160.dp)) {
        item { AuroraHeader(songs.size) }
        item { SectionHeader("Recently added") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                items(recent, key = { it.id }) { s ->
                    TileCard(s.title, s.artist, s.artUri) {
                        onPlay(recent, recent.indexOf(s))
                    }
                }
            }
        }
        item { SectionHeader("Albums") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                items(albums, key = { it.id }) { a ->
                    TileCard(a.title, a.artist, a.artUri) {
                        val tracks = songs.filter { it.albumId == a.id }.sortedBy { it.track }
                        onPlay(tracks, 0)
                    }
                }
            }
        }
        item { SectionHeader("Artists") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                items(artists, key = { it.name }) { a ->
                    TileCard(a.name, "${a.songCount} songs", a.artUri) {
                        onPlay(songs.filter { it.artist == a.name }, 0)
                    }
                }
            }
        }
        item { SectionHeader("Picked for tonight") }
        items(picks, key = { it.id }) { s ->
            SongRow(s, s.id == currentId, s.id in favourites,
                onClick = { onPlay(picks, picks.indexOf(s)) }, onMenu = { onMenu(s) })
        }
    }
}

@Composable
private fun AuroraHeader(count: Int) {
    val t = rememberInfiniteTransition(label = "aurora")
    val shift by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
        label = "shift"
    )
    Box(
        Modifier
            .fillMaxWidth()
            .height(190.dp)
            .padding(16.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(Violet, Mint, InkElevated),
                    start = Offset(shift * 700f, 0f),
                    end = Offset(700f - shift * 500f, 620f)
                )
            )
    ) {
        Column(Modifier.align(androidx.compose.ui.Alignment.BottomStart).padding(22.dp)) {
            Text("JUKETOWN", style = MaterialTheme.typography.labelSmall, color = Ink)
            Text("Your sound,\nbeautifully kept.",
                style = MaterialTheme.typography.headlineMedium, color = Ink)
            Spacer(Modifier.height(6.dp))
            Text("$count tracks in your library",
                style = MaterialTheme.typography.bodyMedium, color = Ink.copy(alpha = 0.7f))
        }
    }
}
